/* 
 * File:   constants_fir.h
 * Author: ygorra
 *
 * Created on 17 octobre 2013, 12:37
 */

#ifndef CONSTANTS_FIR_H
#define	CONSTANTS_FIR_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* CONSTANTS_FIR_H */

