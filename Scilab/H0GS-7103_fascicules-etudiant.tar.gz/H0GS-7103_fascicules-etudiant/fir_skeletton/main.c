/* 
 * File:   main.c
 * Author: ygorra
 *
 * Created on 17 octobre 2013, 12:16
 */

#include <stdio.h>
#include <stdlib.h>
#include "fir.h"
/*
 * 
 */
int main(int argc, char** argv) {
    teste_fir();
    return (EXIT_SUCCESS);
}

