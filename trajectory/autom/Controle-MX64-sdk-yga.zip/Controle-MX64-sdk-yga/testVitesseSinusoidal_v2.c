#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include <math.h>
#include <bits/stdio2.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"
#include "util.h"
#include <math.h>
void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);
#define NB_ECH_MAX 10000
#define NB_COL_MAX 10
#define SHOW_LATENCY

typedef struct {
    int nb_sample, nb_col;
    int data[NB_ECH_MAX][NB_COL_MAX];
} struct_data;

void print_data_testVitesseSinusoidal_v2(struct_data *sd) {
    int i, j;
    printf("data=struct();\n");
    printf("data.description_experience=\"Consigne de couple sinusoidale, avec asservissement\";\n");
    printf("data.values=zeros(%d,%d);", sd->nb_sample, sd->nb_col);
    printf("%% Indices des colonnes de données\n");
    printf("data.col_time=1;\n");
    printf("data.col_position=2;\n");
    printf("data.col_vitesse=3;\n");
    printf("data.col_current=4;\n");
    printf("data.col_load=5;\n");
    printf("data.col_consigne=6;\n");
    printf("i=0;\n");
    for (i = 0; i < sd->nb_sample; i++) {
        printf("i=i+1;data.values(i,:)=[");
        for (j = 0; j < sd->nb_col; j++) {
            printf("%d", sd->data[i][j]);
            if (j + 1 < sd->nb_col) {
                printf(",");
            }
        }
        printf("];\n");
    }
}

void file_print_data_testVitesseSinusoidal_v2(struct_data *sd, char *file_name) {
    int i, j;
    FILE *f = fopen(file_name, "w");
    fprintf(f, "_COUPLE=1;\n");
    fprintf(f, "_VITESSE=2;\n");

    fprintf(f, "data=struct();\n");
    fprintf(f, "data.type_experience=_VITESSE;\n");
    fprintf(f, "data.file_name='%s';\n", file_name);

    fprintf(f, "data.description_experience=\"Consigne de vitesse sinusoidale, avec asservissement\";\n");
    fprintf(f, "data.values=zeros(%d,%d);", sd->nb_sample, sd->nb_col);
    fprintf(f, "%% Indices des colonnes de données\n");
    fprintf(f, "data.col_time=1;\n");
    fprintf(f, "data.col_position=2;\n");
    fprintf(f, "data.col_vitesse=3;\n");
    fprintf(f, "data.col_current=4;\n");
    fprintf(f, "data.col_load=5;\n");
    fprintf(f, "data.col_consigne=6;\n");
    fprintf(f, "i=0;\n");
    for (i = 0; i < sd->nb_sample; i++) {
        fprintf(f, "i=i+1;data.values(i,:)=[");
        for (j = 0; j < sd->nb_col; j++) {
            fprintf(f, "%d", sd->data[i][j]);
            if (j + 1 < sd->nb_col) {
                fprintf(f, ",");
            }
        }
        fprintf(f, "];\n");
    }
    fclose(f);
}

int main_TestVitesseSinusoidal_v2() {
    char ok;
    char file_name[1000], date[1000];
    int baudnum = DEFAULT_BAUDNUM;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceID = DEFAULT_ID;
    //-----------------------------------------
    // parameters
    //---------------------------------------
    double maxSpeed_rpm = 40;
    double minSpeed_rpm = 5;
    double f_hz = 20;
    double w_rad_s = 2 * PI* f_hz;
    double total_time_s = 30; // test duration in s
    if (total_time_s < 10 / f_hz) {
        total_time_s = 20 / f_hz;
    }
#ifdef SHOW_LATENCY
    total_time_s = 1;
#endif
    int data[NB_ECH_MAX][NB_COL_MAX];

    int presentLoadInc, presentPosInc, presentSpeedInc, presentCurrentInc;
    long int presentTimeUs;
#ifdef SHOW_LATENCY
    long int oldTimeUs, maxLatencyUS, minLatencyUS, meanLatencyUS = 0, latencyUS, k_latency = 0;

#endif
    double t_s;
    mx64_struct mx64;
    ok = init_mx64(&mx64, deviceID, deviceIndex, baudnum);
    struct_data sd;

    mx64_turn_on_wheel_mode(&mx64);
    int goalSpeedCentiemeRpm = (int) (0.5 + minSpeed_rpm * 100);
    int nb_sample = 0;
    int j = 0;
    //printf("%%Press Enter key to start...\n");
    //getchar();
    //----------------------------
    // Boucle principale
    //----------------------------
    do {
        presentTimeUs = get_cpu_time_in_microsec();
        t_s = presentTimeUs / 1.0e6;
        if (maxSpeed_rpm != minSpeed_rpm) {
            goalSpeedCentiemeRpm = convert(sin(t_s * w_rad_s), -1, 1, minSpeed_rpm * 100, maxSpeed_rpm * 100, 0);
        }
#ifdef SHOW_LATENCY 
        if (nb_sample > 0) {
            latencyUS = presentTimeUs - oldTimeUs;
            oldTimeUs = presentTimeUs;
            if (nb_sample == 1) {
                maxLatencyUS = latencyUS;
                minLatencyUS = latencyUS;
                meanLatencyUS = 0;
            }
            if (latencyUS > maxLatencyUS) {
                maxLatencyUS = latencyUS;
            } else if (latencyUS < minLatencyUS) {
                minLatencyUS = latencyUS;
            }
            meanLatencyUS += latencyUS;
            k_latency++;

        }
#endif
        mx64_set_goal_speed_centieme_rpm(&mx64, goalSpeedCentiemeRpm);
        mx64_read_all(&mx64);
        sd.data[nb_sample][0] = presentTimeUs;
        sd.data[nb_sample][1] = *(mx64.present_position_data);
        sd.data[nb_sample][2] = *(mx64.present_speed_data);
        sd.data[nb_sample][3] = *(mx64.current_data);
        sd.data[nb_sample][4] = *(mx64.present_load_data);
        sd.data[nb_sample][5] = goalSpeedCentiemeRpm;
        
        // Print result
        nb_sample++;
    } while ((t_s < total_time_s)&&(nb_sample < NB_ECH_MAX));
    mx64_set_goal_speed_rpm(&mx64, 0);
    mx64_turn_off_wheel_mode(&mx64);
    //----------------------------
    // Ecriture données
    //----------------------------

    sd.nb_col = 6;
    sd.nb_sample = nb_sample;
    get_string_date(date, 1000);
    if (maxSpeed_rpm != minSpeed_rpm) {
        snprintf(file_name, 1000, "test_%s_VitesseSinus%dmHz_%drpmX100_%drpmX100.m", date, (int) (f_hz * 1000), (int) (minSpeed_rpm * 100), (int) (maxSpeed_rpm * 100));
    } else {
        snprintf(file_name, 1000, "test_%s_VitesseCte%drpmX100.m", date, (int) (minSpeed_rpm * 100));
    }
    file_print_data_testVitesseSinusoidal_v2(&sd, file_name);
#ifdef SHOW_LATENCY
    meanLatencyUS /= k_latency;
    printf("%% min Latency= %f ms, max Latency =%f ms, mean Latency = %f ms\n",
            (float) (minLatencyUS * 0.001), (float) (maxLatencyUS * 0.001), (float) (meanLatencyUS * 0.001)


            );
#endif
    //----------------------------
    // Arret communication
    //----------------------------

    dxl_terminate();
    return 0;
}
