//##########################################################
//##                      R O B O T I S                   ##
//##          ReadWrite Example code for Dynamixel.       ##
//##                                           2009.11.10 ##
//##########################################################
#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"


void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);

int main_TestMx64() {
    int CommStatus;
    int baudnum = DEFAULT_BAUDNUM;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceID = DEFAULT_ID;

    int GoalPos[2] = {0, 1023};
    //int GoalPos[2] = {0, 4095}; // for Ex series
    int index = 0;
    int Moving;
    float PresentPos, PresentSpeed, PresentLoad;

    printf("\n\nTest on MX-64-AT \n\n");
    char ok;
    mx64_struct mx64;
    ok = init_mx64(&mx64, deviceID, deviceIndex, baudnum);

    // Read baud_rate
    int baud_rate;
    ok = mx64_read_baudrate(&mx64, &baud_rate);

    // Read load
    float load;
    ok = mx64_read_load_Ncm(&mx64, &load);

    // Read position
    int position;
    //ok = mx64_read_position_degree(&mx64, &position);

    // Read Set Read PID 
    int gain_d;
    int gain_i;
    int gain_p;
    ok = mx64_read_pid_params(&mx64, &gain_d, &gain_i, &gain_p);
    //ok = mx64_set_pid_params(&mx64, 0, 0, 32);
    //ok = mx64_read_pid_params(&mx64, &gain_d, &gain_i, &gain_p);

    // Update & print mx64
    /*if( update_mx64(&mx64) == 0){
        printf("Failed to update mx64\n");
    } else {
        printf("%%Succeed to update mx64\n");
        print_mx64(&mx64);
    }*/

    while (1) {
        printf("Press Enter key to continue!(press ESC and Enter to quit)\n");
        if (getchar() == 0x1b)
            break;

        mx64_set_goal_position_degree(&mx64, GoalPos[index]);
        do {
            // Read PresentPos, PresentSpeed, PresentLoad
            mx64_read_position_degree(&mx64, &PresentPos);
            mx64_read_speed_rpm(&mx64, &PresentSpeed);
            mx64_read_load_Ncm(&mx64, &PresentLoad);
            // Print result
            printf("Position: %f, Speed: %f, Load: %f\n", PresentPos, PresentSpeed, PresentLoad);
            // Check Moving
            ok = mx64_read_moving(&mx64, &Moving);
            if (ok) {
                if (Moving == 0) {
                    // Change goal position
                    if (index == 0)
                        index = 1;
                    else
                        index = 0;
                }
            } else {
                PrintCommStatus(CommStatus);
                break;
            }
        } while (Moving == 1);
    }

    // Close device
    dxl_terminate();
    printf("Press Enter key to terminate...\n");
    getchar();
    return 0;
}
