#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include <math.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"
#include "util.h"


void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);

int main_TestCoupleSinusoidal_v1() {
    char ok;
    int baudnum = DEFAULT_BAUDNUM;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceID = DEFAULT_ID;

    float PresentLoadNcm;
    float PresentPosDegree, PresentSpeedRpm, PresentLoadNm, PresentPosRad, PresentSpeedRadps, PresentCurrentA;
    long int PresentTimeUs;
    mx64_struct mx64;
    ok = init_mx64(&mx64, deviceID, deviceIndex, baudnum);

    printf("data=struct();\n");
    printf("data.description_experience=\"Consigne de couple sinusoidale, avec asservissement\";\n");
    printf("data.values=zeros(10000,6);");
    printf("%% Indices des colonnes de données\n");
    printf("data.col_time=1;\n");
    printf("data.col_position=2;\n");
    printf("data.col_vitesse=3;\n");
    printf("data.col_current=4;\n");
    printf("data.col_load=5;\n");
    printf("data.col_consigne=6;\n");
    printf("i=0;\n");

    mx64_turn_on_torque_mode(&mx64);
    int GoalTorqueUp = 2200; // A modifier (mettre en Nm et non mA)
    int GoalTorqueDown = 200;
    int GoalTorque;
    int i = 0;
    int j = 0;

    while (1) {
        printf("%%Press Enter key to continue!(press ESC and Enter to quit)\n");
        if (getchar() == 0x1b)
            break;

        j = 0;
        do {
            if ((j % 2) == 0) {
                GoalTorque = GoalTorqueUp;
            } else {
                GoalTorque = GoalTorqueDown;
            }
            i = 0;
            mx64_set_goal_torque_mA(&mx64, GoalTorque);
            do {
                // Read PresentPos, PresentSpeed, PresentLoad, PresentCurrent
                mx64_read_position_degree(&mx64, &PresentPosDegree);
                mx64_read_speed_rpm(&mx64, &PresentSpeedRpm);
                mx64_read_load_Ncm(&mx64, &PresentLoadNcm);
                mx64_read_current_A(&mx64, &PresentCurrentA);
                PresentTimeUs = get_cpu_time_in_microsec();
                // Convert to USI
                PresentPosRad = PresentPosDegree * PI / 180;
                PresentSpeedRadps = PresentSpeedRpm * 2 * PI / 60;
                PresentLoadNm = (float) PresentLoadNcm / 100;

                // Print result
                printf("i=i+1;data.values(i,:)=[%ld,%f,%f,%f,%f,%d];\n", PresentTimeUs, PresentPosRad, PresentSpeedRadps, PresentCurrentA, PresentLoadNm, GoalTorque);
                i++;
            } while (i < 50);
            j++;
        } while (j < 7);
        mx64_write_word(&mx64, 1024, P_GOAL_TORQUE_L);
    }
    // printf("%%data.values=data.values(i,:);\n");

    // Close device
    dxl_terminate();
    printf("%%Press Enter key to terminate...\n");
    getchar();
    return 0;
}
