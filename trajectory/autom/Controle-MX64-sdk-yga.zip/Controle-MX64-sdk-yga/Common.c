// Print communication result

#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include "dynamixel.h"
#include "Common.h"

void PrintCommStatus(int CommStatus) {
    switch (CommStatus) {
        case COMM_TXFAIL:
            printf("COMM_TXFAIL: Failed transmit instruction packet!\n");
            break;

        case COMM_TXERROR:
            printf("COMM_TXERROR: Incorrect instruction packet!\n");
            break;

        case COMM_RXFAIL:
            printf("COMM_RXFAIL: Failed get status packet from device!\n");
            break;

        case COMM_RXWAITING:
            printf("COMM_RXWAITING: Now recieving status packet!\n");
            break;

        case COMM_RXTIMEOUT:
            printf("COMM_RXTIMEOUT: There is no status packet!\n");
            break;

        case COMM_RXCORRUPT:
            printf("COMM_RXCORRUPT: Incorrect status packet!\n");
            break;

        default:
            printf("This is unknown error code!\n");
            break;
    }
}

// Print error bit of status packet

void PrintErrorCode() {
    if (dxl_get_rxpacket_error(ERRBIT_VOLTAGE) == 1)
        printf("Input voltage error!\n");

    if (dxl_get_rxpacket_error(ERRBIT_ANGLE) == 1)
        printf("Angle limit error!\n");

    if (dxl_get_rxpacket_error(ERRBIT_OVERHEAT) == 1)
        printf("Overheat error!\n");

    if (dxl_get_rxpacket_error(ERRBIT_RANGE) == 1)
        printf("Out of range error!\n");
    

    if (dxl_get_rxpacket_error(ERRBIT_CHECKSUM) == 1)
        printf("Checksum error!\n");

    if (dxl_get_rxpacket_error(ERRBIT_OVERLOAD) == 1)
        printf("Overload error!\n");

    if (dxl_get_rxpacket_error(ERRBIT_INSTRUCTION) == 1)
        printf("Instruction code error!\n");
}

void mydxl_lock_eeprom(int ID, char value) {
    if (value == mytrue) {
        dxl_write_byte(ID, P_EEPROM_LOCK, P_EEPROM_CAN_NOT_BE_MODIFIED);
    } else {
        dxl_write_byte(ID, P_EEPROM_LOCK, P_EEPROM_CAN_BE_MODIFIED);
    }

}

float scale_with_saturation(float x, float x0, float x1, float y0, float y1);

float scale(float x, float x0, float x1, float y0, float y1, char saturation) {
    if (saturation) {
        return scale_with_saturation(x, x0, x1, y0, y1);
    }
    float y = (y1 - y0)*(x - x0) / (x1 - x0) + y0;
    return y;
}

float scale_with_saturation(float x, float x0, float x1, float y0, float y1) {
    float lambda = (x - x0) / (x1 - x0);
    if (lambda > 1) {
        return y1;
    }
    if (lambda < 0) {
        return y0;
    }
    float y = (y1 - y0) * lambda + y0;
    return y;
}