#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include <math.h>
#include <bits/stdio2.h>
#include "dynamixel.h"
#include "MX-64.h"
#include "Common.h"
#include "util.h" //usefull only for use of function convert

char mx64_read_data(mx64_struct *m, char *data, int adresse, int size) {
    dxl_read_data(m->ID, adresse, size, data);
    char ok = dxl_succces(m->verbose);
    return ok;
}

char mx64_read_all(mx64_struct *m) {
    char ok;
    if (m->switch_first_read==mytrue) {
    // read all data from  P_MODEL_NUMBER_L to P_P_GAIN
       ok = mx64_read_data(m, &(m->data[P_MODEL_NUMBER_L]), P_MODEL_NUMBER_L, 1 + P_P_GAIN - P_MODEL_NUMBER_L); 
    }
    // read all data from  P_GOAL_POSITION_L to P_GOAL_ACCELERATION
    ok = ok && mx64_read_data(m, &(m->data[P_GOAL_POSITION_L]), P_GOAL_POSITION_L, 1 + P_GOAL_ACCELERATION - P_GOAL_POSITION_L);
    return ok;
}

char init_mx64(mx64_struct *m, int ID, int deviceIndex, int baudnum) {
    m->ID = ID;
    m->device_index = deviceIndex;
    m->baudnum = baudnum;
    m->eeprom_lock = mytrue;
    m->verbose = PEU_BAVARD;
        m->switch_first_read = mytrue;
    // init pointers on data, to gain time when reading
    m->goal_position_data = (short int *) &m->data[ P_GOAL_POSITION_L]; //30
    m->moving_speed_data = (short int *) &m->data[ P_MOVING_SPEED_L]; //	32
    m->torque_limit_data = (short int *) &m->data[ P_TORQUE_LIMIT_L]; //	34
    m->present_position_data = (short int *) &m->data[ P_PRESENT_POSITION_L]; //	36
    m->present_speed_data = (short int *) &m->data[ P_PRESENT_SPEED_L]; //	38
    m->present_load_data = (short int *) &m->data[ P_PRESENT_LOAD_L]; //	40
    m->present_voltage_data = (unsigned char *) &m->data[ P_PRESENT_VOLTAGE]; //	42
    m->present_temperature_data = (unsigned char *) &m->data[ P_PRESENT_TEMPERATURE]; //	43
    m->registered_data = (unsigned char *) &m->data[ P_REGISTERED]; //    	44
    m->moving_data = (unsigned char *) &m->data[ P_MOVING]; //           	46
    m->eeprom_lock_data = (unsigned char *) &m->data[ P_EEPROM_LOCK]; //   	47
    m->punch_data = (short int *) &m->data[ P_PUNCH_L]; //               48
    m->current_data = (short int *) &m->data[ P_CURRENT_L]; //             68
    m->torque_control_mode_enable_data = (unsigned char *) &m->data[ P_TORQUE_CONTROL_MODE_ENABLE]; //	70
    m->goal_torque_data = (short int *) &m->data[ P_GOAL_TORQUE_L]; //         71
    m->goal_acceleration_data = (unsigned char *) &m->data[ P_GOAL_ACCELERATION]; //	73

    if (dxl_initialize(m->device_index, m->baudnum) == 0) {
        printf("Failed to open USB2Dynamixel!\n");
        printf("Press Enter key to terminate...\n");
        getchar();
        return 0;
    } else {
        printf("%%Succeed to open USB2Dynamixel!\n");
        mx64_read_all(m);
        m->switch_first_read = myfalse;
    }
    return 1;
}

void end_mx64(mx64_struct *m) {
    // Nothing to do now
}

char update_mx64(mx64_struct *m) {
    mx64_read_all(m);
    return 1;
}

void print_mx64(mx64_struct *m) {
    printf("\nMX-64 ID : %d\n", m->ID);
    printf("device_index : %d\n", m->device_index);
    printf("baudnum : %d\n", m->baudnum);
    printf("eeprom_lock : %d\n", m->eeprom_lock);

    printf("\n");
}

char mx64_read_baudrate(mx64_struct *m, int *baud_rate_number) {
    char ok = mx64_read_byte(m, baud_rate_number, P_BAUD_RATE);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read baud_rate\n");
        } else {
            printf("%%Succeed to read: baud_rate = %d\n", *baud_rate_number);
        }
    }
    return ok;
}

char mx64_read_moving(mx64_struct *m, int *moving) {
    char ok = mx64_read_byte(m, moving, P_MOVING);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read moving\n");
        } else {
            printf("%%Succeed to read: moving = %d\n", *moving);
        }
    }
    return ok;
}

char mx64_read_current_inc(mx64_struct *m, int *currentInc) {
    int current_read;
    char ok = mx64_read_word(m, currentInc, P_CURRENT_L);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read current\n");
        } else {
            printf("%%Succeed to read: current = %d\n", *currentInc);
        }
    }
    return ok;
}

char mx64_read_current_A(mx64_struct *m, float *currentA) {
    int current_read;
    char ok = mx64_read_word(m, &current_read, P_CURRENT_L);
    if (ok) {
        *currentA = scale(current_read, 0, 4095, -9.2115, 9.2115, mytrue);
    }
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read current\n");
        } else {
            printf("%%Succeed to read: current = %f\n", *currentA);
        }
    }
    return ok;
}

char mx64_read_load_Ncm(mx64_struct *m, float *loadNcm) {
    int load_read;
    char ok = mx64_read_word(m, &load_read, P_PRESENT_LOAD_L);
    if (ok) {
        // Conversion de load en Newton centimetre.
        if ((load_read) & 1024) {
            load_read = 1024 - load_read;
        }
        *loadNcm = round(scale(load_read, -1023, 1023, -730, 730, mytrue));
    }
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read load\n");
        } else {
            printf("%%Succeed to read: load = %f\n", *loadNcm);
        }
    }
    return ok;
}

char mx64_read_load_inc(mx64_struct *m, int *loadInc) {
    char ok = mx64_read_word(m, loadInc, P_PRESENT_LOAD_L);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read load\n");
        } else {
            printf("%%Succeed to read: load = %d\n", *loadInc);
        }
    }
    return ok;
}

char mx64_read_position_inc(mx64_struct *m, int *positionInc) {
    char ok = mx64_read_word(m, positionInc, P_PRESENT_POSITION_L);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read position\n");
        } else {
            printf("%%Succeed to read: position = %d\n", *positionInc);
        }
    }
    return ok;
}

char mx64_read_position_degree(mx64_struct *m, float *positionDegree) {
    int position_read;
    char ok = mx64_read_word(m, &position_read, P_PRESENT_POSITION_L);
    if (ok) {
        // Conversion de position en degree.
        *positionDegree = scale(position_read, 0, 4095, 0, 360, myfalse);
    }
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read position\n");
        } else {
            printf("%%Succeed to read: position = %f\n", *positionDegree);
        }
    }
    return ok;
}

char mx64_read_speed_inc(mx64_struct *m, int *speedInc) {
    char ok = mx64_read_word(m, speedInc, P_PRESENT_SPEED_L);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read speed\n");
        } else {
            printf("%%Succeed to read: speed = %d\n", *speedInc);
        }
    }
    return ok;
}

char mx64_read_speed_rpm(mx64_struct *m, float *speedRpm) {
    int speed_read;
    char ok = mx64_read_word(m, &speed_read, P_PRESENT_SPEED_L);
    if (ok) {
        // Conversion de speed en tour par minute.
        if ((speed_read) & 1024) {
            speed_read = 1024 - speed_read;
        }
        *speedRpm = scale(speed_read, -1023, 1023, -117.07, 117.07, mytrue);
    }
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read speed\n");
        } else {
            printf("%%Succeed to read: speed = %f\n", *speedRpm);
        }
    }
    return ok;
}

char mx64_set_speed_limit_rpm(mx64_struct *m, float speed_limit_rpm) {
    int speed_sent = round(scale(speed_limit_rpm, 0, 117.07, 0, 1023, mytrue));
    char ok = mx64_write_word(m, speed_sent, P_MOVING_SPEED_L);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to write speed_limit_rpm\n");
        } else {
            printf("%%Succeed to write: speed_limit_rpm = %f\n", speed_limit_rpm);
        }
    }
    return ok;
}

char mx64_set_goal_position_degree(mx64_struct *m, float goal_position_degree) {
    int position_sent = round(scale(goal_position_degree, 0, 360, 0, 4095, mytrue));
    char ok = mx64_write_word(m, position_sent, P_GOAL_POSITION_L);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to write goal_position_degree\n");
        } else {
            printf("%%Succeed to write: goal_position_degree = %f\n", goal_position_degree);
        }
    }
    return ok;
}

char mx64_set_goal_acceleration_dps2(mx64_struct *m, float goal_acceleration_dps2) {
    int acceleration_sent = round(scale(goal_acceleration_dps2, 0, 2180, 0, 254, mytrue));
    char ok = mx64_write_byte(m, acceleration_sent, P_GOAL_ACCELERATION);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to write goal_acceleration_dps2\n");
        } else {
            printf("%%Succeed to write: goal_acceleration_dps2 = %f\n", goal_acceleration_dps2);
        }
    }
    return ok;
}

char mx64_set_goal_torque_mA(mx64_struct *m, int goal_torque_mA) {
    // be carefull, sign inversion
    int torque_sent;
    if (goal_torque_mA >= 0) {
        torque_sent = (int) convert(goal_torque_mA, 0, 4600, 1024, 2047, mytrue);
    } else {
        torque_sent = (int) convert(-goal_torque_mA, 0, 4600, 0, 1023, mytrue);
    }
    char ok = mx64_write_word(m, torque_sent, P_GOAL_TORQUE_L);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to write goal_torque_mA\n");
        } else {
            printf("%%Succeed to write: goal_torque_mA = %d\n", goal_torque_mA);
        }
    }
    return ok;
}

char mx64_turn_on_torque_mode(mx64_struct *m) {
    mx64_write_byte(m, 1, P_TORQUE_CONTROL_MODE_ENABLE);
}

char mx64_turn_off_torque_mode(mx64_struct *m) {
    mx64_write_byte(m, 0, P_TORQUE_CONTROL_MODE_ENABLE);
}

char mx64_turn_on_wheel_mode(mx64_struct *m) {
    mx64_write_word(m, 0, P_CW_ANGLE_LIMIT_L);
    mx64_write_word(m, 0, P_CCW_ANGLE_LIMIT_L);
}

char mx64_turn_off_wheel_mode(mx64_struct *m) {
    mx64_write_word(m, 0, P_CW_ANGLE_LIMIT_L);
    mx64_write_word(m, 4095, P_CCW_ANGLE_LIMIT_L);
}

char mx64_set_goal_speed_rpm(mx64_struct *m, float goal_speed_rpm) {
    int speed_sent;
    if (goal_speed_rpm < 0) {
        speed_sent = round(scale((0 - speed_sent), 0, 117.07, 0, 1023, mytrue));
    } else {
        speed_sent = round(scale(goal_speed_rpm, 0, 117.07, 1024, 2047, mytrue));
    }

    char ok = mx64_write_word(m, speed_sent, P_MOVING_SPEED_L);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("%%Failed to write speed_limit_rpm\n");
        } else {
            //printf("%%Succeed to write: speed_limit_rpm = %f\n", speed_limit_rpm);
        }
    }
    return ok;
}

char mx64_read_return_delay_time_us(mx64_struct *m, int *return_delay_time_us) {
    int return_delay_time_inc;
    char ok = mx64_read_byte(m, &return_delay_time_inc, P_RETURN_DELAY_TIME);
    if (ok) {
        *return_delay_time_us = (int) round(scale(return_delay_time_inc, 0, 255, 0, 255 * 2, mytrue));
    }
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("Failed to read return delay time\n");
        } else {
            printf("%%Succeed to read: return delay time us = %d\n", *return_delay_time_us);
        }
    }
    return ok;
}

char mx64_set_return_delay_time_us(mx64_struct *m, int return_delay_time_us) {
    int delay_value;
    delay_value = (int) round(scale(return_delay_time_us, 0, 2.0 * 255, 0.0, 255.0, mytrue));
    char ok = mx64_write_byte(m, delay_value, P_RETURN_DELAY_TIME);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("%%Failed to write delay time\n");
        } else {
            //printf("%%Succeed to write: speed_limit_rpm = %f\n", speed_limit_rpm);
        }
    }
    return ok;
}

char mx64_set_goal_speed_centieme_rpm(mx64_struct *m, int goal_speed_centieme_rpm) {
    int speed_sent;
    if (goal_speed_centieme_rpm < 0) {
        speed_sent = (int) scale(-goal_speed_centieme_rpm, 0, 11707, 0, 1023, mytrue);
    } else {
        speed_sent = (int) scale(goal_speed_centieme_rpm, 0, 11707, 1024, 2047, mytrue);
    }

    char ok = mx64_write_word(m, speed_sent, P_MOVING_SPEED_L);
    if (m->verbose == TRES_BAVARD) {
        if (ok == 0) {
            printf("%%Failed to write speed_centieme_rpm\n");
        } else {
            //printf("%%Succeed to write: speed_centieme_rpm = %f\n", speed_centieme_rpm);
        }
    }
    return ok;
}

char mx64_read_pid_params(mx64_struct *m, int *d, int *i, int *p) {
    char ok1 = mx64_read_byte(m, d, P_D_GAIN);
    if (m->verbose == TRES_BAVARD) {
        if (ok1 == 0) {
            printf("Failed to read d\n");
        } else {
            printf("%%Succeed to read: d = %d\n", *d);
        }
    }
    char ok2 = mx64_read_byte(m, i, P_I_GAIN);
    if (m->verbose == TRES_BAVARD) {
        if (ok2 == 0) {
            printf("Failed to read i\n");
        } else {
            printf("%%Succeed to read: i = %d\n", *i);
        }
    }
    char ok3 = mx64_read_byte(m, p, P_P_GAIN);
    if (m->verbose == TRES_BAVARD) {
        if (ok3 == 0) {
            printf("Failed to read p\n");
        } else {
            printf("%%Succeed to read: p = %d\n", *p);
        }
    }
    return ok1 && ok2&&ok3;
}

char mx64_set_pid_params(mx64_struct *m, int d, int i, int p) {
    char ok1 = mx64_write_byte(m, d, P_D_GAIN);
    if (m->verbose == TRES_BAVARD) {
        if (ok1 == 0) {
            printf("Failed to write d\n");
        } else {
            printf("%%Succeed to write: d = %d\n", d);
        }
    }
    char ok2 = mx64_write_byte(m, i, P_I_GAIN);
    if (m->verbose == TRES_BAVARD) {
        if (ok2 == 0) {
            printf("Failed to write i\n");
        } else {
            printf("%%Succeed to write: i = %d\n", i);
        }
    }
    char ok3 = mx64_write_byte(m, i, P_P_GAIN);
    if (m->verbose == TRES_BAVARD) {
        if (ok3 == 0) {
            printf("Failed to write p\n");
        } else {
            printf("%%Succeed to write: p = %d\n", p);
        }
    }
    return ok1 && ok2&&ok3;
}

char mx64_read_byte(mx64_struct *m, int *value, int adresse) {
    *value = dxl_read_byte(m->ID, adresse);
    char ok = dxl_succces(m->verbose);
    return ok;
}

char mx64_write_byte(mx64_struct *m, int value, int adresse) {
    dxl_write_byte(m->ID, adresse, value);
    char ok = dxl_succces(m->verbose);
    return ok;
}
#define MAX_DXL_DATA_SIZE 1000



char mx64_read_word(mx64_struct *m, int *value, int adresse) {
    *value = dxl_read_word(m->ID, adresse);
    char ok = dxl_succces(m->verbose);
    return ok;
}

char mx64_write_word(mx64_struct *m, int value, int adresse) {
    dxl_write_word(m->ID, adresse, value);
    char ok = dxl_succces(m->verbose);
    return ok;
}

void mx64_get_state(mx64_struct *m, char *state_msg, int size_max_msg) {
    int n0 = 0, size_writed;
    size_writed = snprintf(state_msg + n0, size_max_msg, " // state of MX_64[ ID = %d ]\n", m->ID);
    n0 = n0 + size_writed;
    size_max_msg -= size_writed;


}