/* 
 * File:   Common.h
 * Author: jerome
 *
 * Created on 13 novembre 2014, 15:32
 */

#ifndef COMMON_H
#define	COMMON_H

#define mytrue      1   
#define myfalse     0  

// Control table address
#define P_MODEL_NUMBER_L        0
#define P_MODEL_NUMBER_H        1
#define P_VERSION_OF_FIRWARE    2
#define P_ID                    3
#define P_BAUD_RATE             4
#define P_RETURN_DELAY_TIME     5
#define P_CW_ANGLE_LIMIT_L      6
#define P_CW_ANGLE_LIMIT_H      7
#define P_CCW_ANGLE_LIMIT_L     8
#define P_CCW_ANGLE_LIMIT_H     9
#define P_THE_HIGHEST_LIMIT_TEMPERATURE       11
#define P_THE_LOWEST_LIMIT_VOLTAGE            12
#define P_THE_HIGHEST_LIMIT_VOLTAGE           13
#define P_MAX_TORQUE_L          14
#define P_MAX_TORAQUE_H         15
#define P_STATUS_RETURN_LEVEL   16
#define P_ALARM_LED             17
#define P_ALARM_SHUTDOWM        18
#define P_MULTI_TURN_OFFSET_L   20
#define P_MULTI_TURN_OFFSET_H   21
#define P_RESOLUTION_DIVIDER    22
#define P_TORQUE_ENABLE         24
#define P_LED                   25
#define P_D_GAIN                26
#define P_I_GAIN                27
#define P_P_GAIN                28
#define P_GOAL_POSITION_L	30
#define P_GOAL_POSITION_H	31
#define P_MOVING_SPEED_L	32
#define P_MOVING_SPEED_H	33
#define P_TORQUE_LIMIT_L	34
#define P_TORQUE_LIMIT_H	35
#define P_PRESENT_POSITION_L	36
#define P_PRESENT_POSITION_H	37
#define P_PRESENT_SPEED_L	38
#define P_PRESENT_SPEED_H	39
#define P_PRESENT_LOAD_L	40
#define P_PRESENT_LOAD_H	41
#define P_PRESENT_VOLTAGE	42
#define P_PRESENT_TEMPERATURE	43
#define P_REGISTERED    	44
#define P_MOVING           	46
#define P_EEPROM_LOCK   	47
#define P_PUNCH_L               48
#define P_PUNCH_H               49
#define P_UNKNOWN1_L            52
#define P_UNKNOWN1_H            53
#define P_UNKNOWN2_L            54
#define P_UNKNOWN2_H            55
#define P_UNKNOWN3              56
#define P_UNKNOWN4_L            58
#define P_UNKNOWN4_H            59
#define P_UNKNOWN5_L            60
#define P_UNKNOWN5_H            61
#define P_UNKNOWN6_L            62
#define P_UNKNOWN6_H            63

#define P_CURRENT_L             68
#define P_CURRENT_H             69
#define P_TORQUE_CONTROL_MODE_ENABLE	70
#define P_GOAL_TORQUE_L         71
#define P_GOAL_TORQUE_H         72
#define P_GOAL_ACCELERATION	73


// Possible values for P_BAUD_RATE, see http://support.robotis.com/en/product/dynamixel/mx_series/mx-64.htm#Actuator_Address_04
//Baudrate(BPS)  = 2000000 / (Data + 1)
//Data Set BPS Target BPS Tolerance
//1 1000000.0 1000000.0
//3 500000.0 500000.0
//4 400000.0 400000.0
//7 250000.0 250000.0
//9 200000.0 200000.0
//16 117647.1 115200.0 -2.124 %
//34 57142.9 57600.0  0.794 %
//103 19230.8 19200.0  -0.160 %
//207 9615.4 9600.0 -0.160 %
//250 2250000.0 2250000.0  0.000 %
//251 2500000.0 2500000.0 0.000 %
//252 3000000.0 3000000.0  0.000 %
#define V_BAUD_RATE_1MHZ        1
#define V_BAUD_RATE_57KHZ       34
#define V_BAUD_RATE_2250KHZ     250
#define V_BAUD_RATE_2500KHZ     251
#define V_BAUD_RATE_3MHZ        252


#define P_EEPROM_CAN_BE_MODIFIED      0   
#define P_EEPROM_CAN_NOT_BE_MODIFIED  1  

// Defulat setting
#define DEFAULT_BAUDNUM		V_BAUD_RATE_3MHZ // 1Mbps  voir baudrate http://support.robotis.com/en/techsupport_eng.htm#product/dynamixel/mx_series/mx-64.htm
#define DEFAULT_ID		1
#define DEFAULT_DEVICE_INDEX    0
#define ID_ALL_MOTORS		254


#ifdef	__cplusplus
extern "C" {
#endif



    void PrintCommStatus(int CommStatus);
    void PrintErrorCode();
    void lock_eeprom();
    float scale(float x, float x0, float x1, float y0, float y1, char saturation);


#ifdef	__cplusplus
}
#endif

#endif	/* COMMON_H */

