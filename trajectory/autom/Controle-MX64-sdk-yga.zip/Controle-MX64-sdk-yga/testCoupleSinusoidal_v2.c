#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include <math.h>
#include <bits/stdio2.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"
#include "util.h"

void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);
#define NB_ECH_MAX 10000
#define NB_COL_MAX 10
//#define SHOW_LATENCY
typedef struct {
    int nb_sample, nb_col;
    int data[NB_ECH_MAX][NB_COL_MAX];
} struct_data;

void print_data_testCoupleSinusoidal_v2(struct_data *sd) {
    int i, j;
    printf("data=struct();\n");
    printf("data.description_experience=\"Consigne de couple sinusoidale, avec asservissement\";\n");
    printf("data.values=zeros(%d,%d);", sd->nb_sample, sd->nb_col);
    printf("%% Indices des colonnes de données\n");
    printf("data.col_time=1;\n");
    printf("data.col_position=2;\n");
    printf("data.col_vitesse=3;\n");
    printf("data.col_current=4;\n");
    printf("data.col_load=5;\n");
    printf("data.col_consigne=6;\n");
    printf("i=0;\n");
    for (i = 0; i < sd->nb_sample; i++) {
        printf("i=i+1;data.values(i,:)=[");
        for (j = 0; j < sd->nb_col; j++) {
            printf("%d", sd->data[i][j]);
            if (j + 1 < sd->nb_col) {
                printf(",");
            }
        }
        printf("];\n");
    }
}

void file_print_data_testCoupleSinusoidal_v2(struct_data *sd, char *file_name) {
    int i, j;
    FILE *f = fopen(file_name, "w");
    fprintf(f, "data=struct();\n");
    fprintf(f, "data.description_experience=\"Consigne de couple sinusoidale, avec asservissement\";\n");
    fprintf(f, "data.values=zeros(%d,%d);", sd->nb_sample, sd->nb_col);
    fprintf(f, "%% Indices des colonnes de données\n");
    fprintf(f, "data.col_time=1;\n");
    fprintf(f, "data.col_position=2;\n");
    fprintf(f, "data.col_vitesse=3;\n");
    fprintf(f, "data.col_current=4;\n");
    fprintf(f, "data.col_load=5;\n");
    fprintf(f, "data.col_consigne=6;\n");
    fprintf(f, "i=0;\n");
    for (i = 0; i < sd->nb_sample; i++) {
        fprintf(f, "i=i+1;data.values(i,:)=[");
        for (j = 0; j < sd->nb_col; j++) {
            fprintf(f, "%d", sd->data[i][j]);
            if (j + 1 < sd->nb_col) {
                fprintf(f, ",");
            }
        }
        fprintf(f, "];\n");
    }
    fclose(f);
}

int main_TestCoupleSinusoidal_v2() {
    char ok;
    char file_name[1000], date[1000];
    int baudnum = DEFAULT_BAUDNUM;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceID = DEFAULT_ID;
    double maxTorque_mA = 1000; // A modifier (mettre en Nm et non mA)
    double minTorque_mA = 1000;
    double f_hz = 10;
    double w_rad_s = 2 * PI* f_hz;
    int data[NB_ECH_MAX][NB_COL_MAX];
    double total_time_s = 5; // test duration in s
    if (total_time_s <10/f_hz) {
        total_time_s =20/f_hz;
    } 
    int presentLoadInc, presentPosInc, presentSpeedInc, presentCurrentInc;
    long int presentTimeUs;
    double t_s;
    mx64_struct mx64;
    ok = init_mx64(&mx64, deviceID, deviceIndex, baudnum);
    struct_data sd;

    mx64_turn_on_torque_mode(&mx64);
    int goalCurrent_mA = minTorque_mA;
    int nb_sample = 0;
    int j = 0;
    printf("%%Press Enter key to start...\n");
    getchar();
    //----------------------------
    // Boucle principale
    //----------------------------
    do {
        presentTimeUs = get_cpu_time_in_microsec();
        t_s = presentTimeUs / 1.0e6;
        if (minTorque_mA != maxTorque_mA) {
            goalCurrent_mA = convert(cos(t_s * w_rad_s), -1, 1, minTorque_mA, maxTorque_mA, 0);
        }
        mx64_set_goal_torque_mA(&mx64, goalCurrent_mA);
        //GoalTorque_mA                
        // Read PresentPos, PresentSpeed, PresentLoad, PresentCurrent
        mx64_read_position_inc(&mx64, &presentPosInc);
        mx64_read_speed_inc(&mx64, &presentSpeedInc);
        mx64_read_load_inc(&mx64, &presentLoadInc);
        mx64_read_current_inc(&mx64, &presentCurrentInc);
        sd.data[nb_sample][0] = presentTimeUs;
        sd.data[nb_sample][1] = presentPosInc;
        sd.data[nb_sample][2] = presentSpeedInc;
        sd.data[nb_sample][3] = presentCurrentInc;
        sd.data[nb_sample][4] = presentLoadInc;
        sd.data[nb_sample][5] = (int) goalCurrent_mA;
        // Print result
        nb_sample++;
    } while ((t_s < total_time_s)&&(nb_sample < NB_ECH_MAX));
    //----------------------------
    // Couple =0
    //----------------------------
    mx64_set_goal_torque_mA(&mx64,0);
    presentTimeUs = get_cpu_time_in_microsec();
    //----------------------------
    // attend 1 seconde et arrete le mode couple
    //----------------------------
    while(get_cpu_time_in_microsec() <presentTimeUs+3000000 );
    mx64_turn_off_torque_mode(&mx64);

    //----------------------------
    // Ecriture données
    //----------------------------

    sd.nb_col = 6;
    sd.nb_sample = nb_sample;
    get_string_date(date, 1000);
    if (maxTorque_mA != minTorque_mA) {
        snprintf(file_name, 1000, "test_%s_CoupleSinus%dmHz_%dmA_%dmA.m", date, (int) (f_hz * 1000), (int) minTorque_mA, (int) maxTorque_mA);
    } else {
        
        snprintf(file_name, 1000, "test_%s_CoupleCte%dmA.m", date, (int) minTorque_mA);
    }
    file_print_data_testCoupleSinusoidal_v2(&sd, file_name);
    //----------------------------
    // Arret communication
    //----------------------------
    while(get_cpu_time_in_microsec() <presentTimeUs+1500000 );
    dxl_terminate();
    return 0;
}

