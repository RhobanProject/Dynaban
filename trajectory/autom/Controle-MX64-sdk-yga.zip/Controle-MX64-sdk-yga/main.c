/* 
 * File:   main.c
 * Author: jerome
 *
 * Created on 13 novembre 2014, 15:26
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main_TestMx64(void);
int main_ReadWrite_V1(void);
int main_ReadWrite_V2(void);
int main_TestVitesseLente(void);
int main_TestVitesseEnRampe(void);
int main_TestCoupleSinusoidal_v1(void);
int main_TestCoupleSinusoidal_v2(void);
int main_TestVitesseSinusoidal_v2(void);
int main_TestData(void);
int main_ModifyBaudRate(void);
int main_TestUsbSpeed(void);
int main_TestCoupleConstant(void);
int main(int argc, char** argv) {
  //  main_TestUsbSpeed();
  // main_ModifyBaudRate(); 
   //main_TestCoupleSinusoidal_v2();
   //main_TestData();
   main_TestCoupleConstant();
   return (EXIT_SUCCESS);
}

