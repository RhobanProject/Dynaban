//##########################################################
//##                      R O B O T I S                   ##
//##          ReadWrite Example code for Dynamixel.       ##
//##                                           2009.11.10 ##
//##########################################################
#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include <math.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"
#include "util.h"


void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);

/*
 * Dans cette experience on place une masse m suspendue au bout d'une tige de 
 * de longueur l et on envoi des c
 
 */


int main_TestVitesseSinusoidale() {
    char ok;
    int baudnum = DEFAULT_BAUDNUM;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceID = DEFAULT_ID;

    int PresentLoadNcm;
    float PresentPosDegree, PresentSpeedRpm, PresentLoadNm, PresentPosRad, PresentSpeedRadps, PresentCurrentA;
    long int PresentTimeUs;
    long int TimeStart;
    int PresentPosInc, PresentSpeedInc, PresentLoadInc, PresentCurrentInc;
    mx64_struct mx64;
    ok = init_mx64(&mx64, deviceID, deviceIndex, baudnum);

    printf("data=struct();\n");
    printf("%% Reglage:\n");
    printf("data.description_experience=\"Mesure du couple lors de la levé d'un poid de 1Kg\";\n");
    printf("data.values=zeros(10000,6);");
    printf("%% Indices des colonnes de données\n");
    printf("data.col_time=1;\n");
    printf("data.col_position=2;\n");
    printf("data.col_vitesse=3;\n");
    printf("data.col_current=4;\n");
    printf("data.col_load=5;\n");
    printf("data.col_consigne=6;\n");
    printf("i=0;\n");

    float GoalspeedRpm;
    mx64_turn_on_wheel_mode(&mx64);


    float fHz = 10.0;
    float fMhz = fHz / 1000000;
    float WMrad_s = 2 * PI*fMhz;

    float verticalOffset = 30.0;
    float amplitude = 10.0;

    long int duree_us = 5000000;

    int i;

    while (1) {
        printf("%%Press Enter key to continue!(press ESC and Enter to quit)\n");
        if (getchar() == 0x1b)
            break;

        printf("%%PresentTimeUs,PresentPosDegree,PresentSpeedRadps,PresentCurrentInc,PresentLoadNm,GoalspeedRpm\n");

        i = 0;
        TimeStart = get_cpu_time_in_microsec();
        do {
            PresentTimeUs = get_cpu_time_in_microsec();
            GoalspeedRpm = verticalOffset + (int) (amplitude * sin(WMrad_s * PresentTimeUs));
            mx64_set_goal_speed_rpm(&mx64, GoalspeedRpm);

            // Read PresentPos, PresentSpeed, PresentLoad, PresentCurrent
            //ok = mx64_read_position_degree(&mx64, &PresentPosDegree);
            //ok = ok && mx64_read_speed_rpm(&mx64, &PresentSpeedRpm);
            //ok = ok && mx64_read_load_Ncm(&mx64, &PresentLoadNcm);
            //ok = ok && mx64_read_current_A(&mx64, &PresentCurrentA);

            ok = mx64_read_position_inc(&mx64, &PresentPosInc);
            ok = ok && mx64_read_speed_inc(&mx64, &PresentSpeedInc);
            ok = ok && mx64_read_load_inc(&mx64, &PresentLoadInc);
            ok = ok && mx64_read_current_inc(&mx64, &PresentCurrentInc);

            // Convert to USI
            //PresentPosRad = PresentPosDegree * PI/180;
            //PresentSpeedRadps = PresentSpeedRpm * 2 * PI/60;
            //PresentLoadNm = ((float)PresentLoadNcm)/100;

            printf("i=i+1;data.values(i,:)=[%ld,%d,%d,%d,%d,%f];\n", PresentTimeUs, PresentPosInc, PresentSpeedInc, PresentCurrentInc, PresentLoadInc, GoalspeedRpm);
            i++;
        } while ((PresentTimeUs - TimeStart) < duree_us);

        printf("data.values=data.values(1:i,:);\n\n");

        mx64_set_goal_speed_rpm(&mx64, 0);
        mx64_turn_off_wheel_mode(&mx64);

    }


    // Close device
    dxl_terminate();
    printf("%%Press Enter key to terminate...\n");
    getchar();
    return 0;
}
