
#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include <math.h>
#include <bits/stdio2.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"
#include "util.h"
#include <math.h>
void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);
#define NB_ECH_MAX 100000
#define NB_COL_MAX 10
#define SHOW_LATENCY

typedef struct {
    int nb_sample, nb_col;
    int data[NB_ECH_MAX][NB_COL_MAX];
} struct_data;

void print_data_testUsbSpeed(struct_data *sd) {
}

void file_print_data_testUsbSpeed(struct_data *sd, char *file_name) {

}

int main_TestUsbSpeed() {
    char ok;
    char file_name[1000], date[1000];
    int baudnum = DEFAULT_BAUDNUM;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceID = DEFAULT_ID;
    //-----------------------------------------
    // parameters
    //---------------------------------------
    char data[1000];
    unsigned char *data_u;
    double total_time_s = 30; // test duration in s
#ifdef SHOW_LATENCY
    total_time_s = 10;
#endif

    int presentLoadInc, presentPosInc, presentSpeedInc, presentCurrentInc;
    long int presentTimeUs;
    int return_delay_time_us;
#ifdef SHOW_LATENCY
    long int oldTimeUs, maxLatencyUS, minLatencyUS, meanLatencyUS = 0, latencyUS, k_latency = 0;
    int nb_sample = 0;
    int nb_sample_start_latency_measure=50; // start latency measure at 50 sample
#endif
    double t_s;
    mx64_struct mx64;
    data_u = (unsigned char *) &(data[0]);
    ok = init_mx64(&mx64, deviceID, deviceIndex, baudnum);
    if (!ok) {
        return 0;
    }
    struct_data sd;
    ok=mx64_read_data(&mx64, &data[0], P_BAUD_RATE, 40);
    if (!ok) {
        return 0;
    }
      printf("baud rate number =%d\n", data_u[0]);
    
    ok = mx64_read_return_delay_time_us(&mx64, &return_delay_time_us);
    if (ok) {
       printf("old return delaytime =%d us \n",return_delay_time_us);
       return_delay_time_us=50;
       printf("set new return delaytime =%d us\n ",return_delay_time_us);
       ok = mx64_set_return_delay_time_us(&mx64, return_delay_time_us);
    }
    ok = mx64_read_return_delay_time_us(&mx64, &return_delay_time_us);
    if (ok) {
       printf("current return delaytime =%d us \n",return_delay_time_us);
    }     

    //----------------------------
    // Boucle principale
    //----------------------------
    do {
        presentTimeUs = get_cpu_time_in_microsec();
        t_s = presentTimeUs / 1.0e6;
#ifdef SHOW_LATENCY 
        if (nb_sample > nb_sample_start_latency_measure) {
            latencyUS = presentTimeUs - oldTimeUs;
            if (k_latency == 0) {
                maxLatencyUS = latencyUS;
                minLatencyUS = latencyUS;
                meanLatencyUS = 0;
            }
            if (latencyUS > maxLatencyUS) {
                maxLatencyUS = latencyUS;
            } else if (latencyUS < minLatencyUS) {
                minLatencyUS = latencyUS;
            }
            meanLatencyUS += latencyUS;
            k_latency++;

        }
#endif
        mx64_read_data(&mx64, &data[0], P_GOAL_POSITION_L, 40);
        // Print result
        nb_sample++;
        oldTimeUs = presentTimeUs;

    } while ((t_s < total_time_s)&&(nb_sample < NB_ECH_MAX));
    //----------------------------
    // Ecriture données
    //----------------------------

#ifdef SHOW_LATENCY
    meanLatencyUS /= k_latency;
    printf("%% min Latency= %f ms, max Latency =%f ms, mean Latency = %f ms\n",
            (float) (minLatencyUS * 0.001), (float) (maxLatencyUS * 0.001), (float) (meanLatencyUS * 0.001)


            );
#endif
    //----------------------------
    // Arret communication
    //----------------------------

    dxl_terminate();
    return 0;
}

