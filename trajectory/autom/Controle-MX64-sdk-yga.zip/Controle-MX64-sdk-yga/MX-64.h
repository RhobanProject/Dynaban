/* 
 * File:   MX-64.h
 * Author: jerome
 *
 * Created on 13 novembre 2014, 16:33
 */
// see doc at :
//
#ifndef MX_64_H
#define	MX_64_H

#include "Common.h"
#define MX64_DATA_SIZE (P_GOAL_ACCELERATION +1)
typedef struct {
    int ID;
    int device_index;
    int baudnum;
    char eeprom_lock;
    char verbose;
    char switch_first_read;
    unsigned char data[MX64_DATA_SIZE];

    short int *goal_position_data; // pointer on data[ P_GOAL_POSITION_L]; //30
    short int *moving_speed_data; // pointer on data[ P_MOVING_SPEED_L]; //	32
    short int *torque_limit_data; // pointer on data[ P_TORQUE_LIMIT_L]; //	34
    short int *present_position_data; // pointer on data[ P_PRESENT_POSITION_L]; //	36
    short int *present_speed_data; // pointer on data[ P_PRESENT_SPEED_L]; //	38
    short int *present_load_data; // pointer on data[ P_PRESENT_LOAD_L]; //	40
    unsigned char *present_voltage_data; // pointer on data[ P_PRESENT_VOLTAGE]; //	42
    unsigned char * present_temperature_data; // pointer on data[ P_PRESENT_TEMPERATURE]; //	43
    unsigned char * registered_data; // pointer on data[ P_REGISTERED]; //    	44
    unsigned char * moving_data; // pointer on data[ P_MOVING]; //           	46
    unsigned char * eeprom_lock_data; // pointer on data[ P_EEPROM_LOCK]; //   	47
    short int *punch_data; // pointer on data[ P_PUNCH_L]; //               48
    short int *current_data; // pointer on data[ P_CURRENT_L]; //             68
    unsigned char * torque_control_mode_enable_data; // pointer on data[ P_TORQUE_CONTROL_MODE_ENABLE]; //	70
    short int *goal_torque_data; // pointer on data[ P_GOAL_TORQUE_L]; //         71
    unsigned char * goal_acceleration_data; // pointer on data[ P_GOAL_ACCELERATION]; //	73
} mx64_struct;


#ifdef	__cplusplus
extern "C" {
#endif

    char init_mx64(mx64_struct *m, int ID, int deviceIndex, int baudnum);
    void end_mx64(mx64_struct *m);

    char update_mx64(mx64_struct *m);
    void print_mx64(mx64_struct *m);
char mx64_read_all(mx64_struct *m);
    char mx64_read_baudrate(mx64_struct *m, int *baud_rate);
    char mx64_read_moving(mx64_struct *m, int *moving);
    char mx64_set_return_delay_time_us(mx64_struct *m, int return_delay_time_us);
    char mx64_read_return_delay_time_us(mx64_struct *m, int *return_delay_time_us);
    char mx64_read_load_Ncm(mx64_struct *m, float *load);
    char mx64_read_position_degree(mx64_struct *m, float *position);
    char mx64_read_speed_rpm(mx64_struct *m, float *speedRpm);
    char mx64_read_current_A(mx64_struct *m, float *currentA);

    char mx64_read_load_inc(mx64_struct *m, int *loadInc);
    char mx64_read_position_inc(mx64_struct *m, int *positionInc);
    char mx64_read_speed_inc(mx64_struct *m, int *speedInc);
    char mx64_read_current_inc(mx64_struct *m, int *currentInc);

    char mx64_set_speed_limit_rpm(mx64_struct *m, float speed_limit_rpm);
    char mx64_set_goal_position_degree(mx64_struct *m, float goal_position);
    char mx64_set_goal_acceleration_dps2(mx64_struct *m, float goal_acceleration_dps2);

    char mx64_set_goal_speed_rpm(mx64_struct *m, float goal_speed_rpm);
    char mx64_set_goal_speed_centieme_rpm(mx64_struct *m, int goal_speed_centieme_rpm);
    char mx64_turn_on_torque_mode(mx64_struct *m);
    char mx64_turn_off_torque_mode(mx64_struct *m);
    char mx64_turn_on_wheel_mode(mx64_struct *m);
    char mx64_turn_off_wheel_mode(mx64_struct *m);


    char mx64_set_pid_params(mx64_struct *m, int d, int i, int p);
    char mx64_read_byte(mx64_struct *m, int *value, int address);
    char mx64_write_byte(mx64_struct *m, int value, int address);
    char mx64_read_word(mx64_struct *m, int *value, int address);
    char mx64_write_word(mx64_struct *m, int value, int address);
    void mx64_get_state(mx64_struct *m, char *state_msg, int size_max_msg);


#ifdef	__cplusplus
}
#endif

#endif	/* MX_64_H */

