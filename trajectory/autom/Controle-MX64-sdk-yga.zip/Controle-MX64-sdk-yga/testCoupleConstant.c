#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include <math.h>
#include <bits/stdio2.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"
#include "util.h"
#include <math.h>
#include <string.h>
void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);
#define NB_ECH_MAX 2000
#define SHOW_LATENCY

typedef struct {
    int nb_sample, nb_col;
    unsigned char data[NB_ECH_MAX][MX64_DATA_SIZE];
    long int t_us[NB_ECH_MAX];
} struct_data;

void print_data_testCoupleConstant(struct_data *sd) {
    int i, j;
    printf("data=struct();\n");
    printf("data.description_experience=\"Consigne de couple sinusoidale, avec asservissement\";\n");
    printf("data.values=zeros(%d,%d);", sd->nb_sample, sd->nb_col);
    printf("%% Indices des colonnes de données\n");
    printf("data.col_position_L=%d;\n", P_PRESENT_POSITION_L);
    printf("data.col_vitesse=3;\n");
    printf("data.col_current=4;\n");
    printf("data.col_load=5;\n");
    printf("data.col_consigne=6;\n");
    printf("i=0;\n");
    for (i = 0; i < sd->nb_sample; i++) {
        printf("i=i+1;data.values(i,:)=[");
        for (j = 0; j < sd->nb_col; j++) {
            printf("%d", sd->data[i][j]);
            if (j + 1 < sd->nb_col) {
                printf(",");
            }
        }
        printf("];\n");
    }
}

void file_print_data_testCoupleConstant(struct_data *sd, char *file_name, int col_debut, int col_fin) {
    int i, j;
    FILE *f = fopen(file_name, "w");
    fprintf(f, "_COUPLE=1;\n");
    fprintf(f, "_VITESSE=2;\n");

    fprintf(f, "data=struct();\n");
    fprintf(f, "data.col=struct();\n");
    fprintf(f, "data.col8=struct();\n");
    fprintf(f, "data.col1024=struct();\n");
    fprintf(f, "data.type_experience=_VITESSE;\n");
    fprintf(f, "data.file_name='%s';\n", file_name);
    fprintf(f, "data.description_experience=\"Consigne de vitesse sinusoidale, avec asservissement\";\n");
    fprintf(f, "data.values=zeros(%d,%d);", sd->nb_sample, col_fin - col_debut + 1);
    fprintf(f, "data.t_us=zeros(%d,1);", sd->nb_sample);
    fprintf(f, "%% Indices des colonnes de données\n");
    fprintf(f, "data.col_deb=%d;\n", col_debut);
    fprintf(f, "data.col_fin=%d;\n", col_fin);
    fprintf(f, "data.col.PRESENT_POSITION_L=%d;\n", P_PRESENT_POSITION_L);
    fprintf(f, "data.col.GOAL_POSITION_L=%d;\n", P_GOAL_POSITION_L);
    fprintf(f, "data.col.MOVING_SPEED_L=%d;\n", P_MOVING_SPEED_L);
    fprintf(f, "data.col.GOAL_POSITION_L=%d;\n", P_GOAL_POSITION_L); //	30
    fprintf(f, "data.col.MOVING_SPEED_L=%d;\n", P_MOVING_SPEED_L); //	32
    fprintf(f, "data.col.TORQUE_LIMIT_L=%d;\n", P_TORQUE_LIMIT_L); //	34
    fprintf(f, "data.col.PRESENT_POSITION_L=%d;\n", P_PRESENT_POSITION_L); //	36
    fprintf(f, "data.col1024.PRESENT_SPEED_L=%d;\n", P_PRESENT_SPEED_L); //	38
    fprintf(f, "data.col1024.PRESENT_LOAD_L=%d;\n", P_PRESENT_LOAD_L); //	40
    fprintf(f, "data.col8.PRESENT_VOLTAGE=%d;\n", P_PRESENT_VOLTAGE); //	42
    fprintf(f, "data.col8.PRESENT_TEMPERATURE=%d;\n", P_PRESENT_TEMPERATURE); //	43
    // fprintf(f, "data.col8.REGISTERED=%d;\n", P_REGISTERED); //    	44
    fprintf(f, "data.col8.MOVING=%d;\n", P_MOVING); //           	46
    // fprintf(f, "data.col8.EEPROM_LOCK=%d;\n", P_EEPROM_LOCK); //   	47
    fprintf(f, "data.col.PUNCH_L=%d;\n", P_PUNCH_L); //               48
    fprintf(f, "data.col.UNKNOWN1_L=%d;\n", P_UNKNOWN1_L); //            52
    fprintf(f, "data.col1024.UNKNOWN2_L=%d;\n", P_UNKNOWN2_L); //            54
    fprintf(f, "data.col.UNKNOWN3=%d;\n", P_UNKNOWN3); //              56
    fprintf(f, "data.col.UNKNOWN4_L=%d;\n", P_UNKNOWN4_L); //            58
    fprintf(f, "data.col.UNKNOWN5_L=%d;\n", P_UNKNOWN5_L); //            60
    fprintf(f, "data.col.UNKNOWN6_L=%d;\n", P_UNKNOWN6_L); //            62
    fprintf(f, "data.col.CURRENT_L=%d;\n", P_CURRENT_L); //             68
    // fprintf(f, "data.col8.TORQUE_CONTROL_MODE_ENABLE=%d;\n", P_TORQUE_CONTROL_MODE_ENABLE); //	70
    fprintf(f, "data.col.GOAL_TORQUE_L=%d;\n", P_GOAL_TORQUE_L); //         71
    fprintf(f, "data.col8.GOAL_ACCELERATION=%d;\n", P_GOAL_ACCELERATION); //	73

    fprintf(f, "i=0;\n");
    for (i = 0; i < sd->nb_sample; i++) {
        fprintf(f, "i=i+1;data.values(i,:)=[");
        for (j = col_debut; j <= col_fin; j++) {
            fprintf(f, "%d", sd->data[i][j]);
            if (j != col_fin) {
                fprintf(f, ",");
            }
        }
        fprintf(f, "];data.t_us(i)=%ld;\n", sd->t_us[i]);
    }

    fprintf(f, "  [m,n]=size(data);\n");
    fprintf(f, "  m1=max(data.values,[],1);\n");
    fprintf(f, "  m2=min(data.values,[],1);\n");
    fprintf(f, "  k=find(m1~=m2);\n");
    fprintf(f, "  k=k+data.col_deb-1;\n");
    fprintf(f, " disp(k);");
    fclose(f);
}

int main_TestCoupleConstant() {
    char ok;
    char file_name[1000], date[1000];
    int baudnum = DEFAULT_BAUDNUM;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceID = DEFAULT_ID;
    char s_maxSpeed[100], s_minSpeed[100];
    //-----------------------------------------
    // parameters
    //---------------------------------------
    double maxCurrent_mA = 10;
    double minCurrent_mA = 10;
    int current_inc;
    double meanCurrent_inc = 0, powCurrent_inc = 0, varCurrent_inc, sdCurrent_inc;
    double meanCurrent_mA, sdCurrent_mA;

    double f_hz = 3;
    double w_rad_s = 2 * PI* f_hz;
    double total_time_s = 10; // test duration in s
    double mes_time_s = 2; // begin measure time
    int k_mes = 0;
#ifdef SHOW_LATENCY
    //  total_time_s = 1;
#endif
    int data[NB_ECH_MAX][MX64_DATA_SIZE];
    int col_debut = P_CURRENT_L;
    int col_fin = P_CURRENT_H;
    long int presentTimeUs;
#ifdef SHOW_LATENCY
    long int oldTimeUs, maxLatencyUS, minLatencyUS, meanLatencyUS = 0, latencyUS, k_latency = 0;

#endif
    double t_s;
    mx64_struct mx64;
    ok = init_mx64(&mx64, deviceID, deviceIndex, baudnum);
    struct_data sd;

    mx64_turn_on_torque_mode(&mx64);
    int goalCurrent_mA = minCurrent_mA;
    mx64_set_goal_torque_mA(&mx64, goalCurrent_mA);
    int nb_sample = 0;
    int j = 0;
    //printf("%%Press Enter key to start...\n");
    //getchar();
    //----------------------------
    // Boucle principale
    //----------------------------
    do {
        if (minCurrent_mA != maxCurrent_mA) {
            goalCurrent_mA = convert(cos(t_s * w_rad_s), -1, 1, minCurrent_mA, maxCurrent_mA, 0);
            mx64_set_goal_torque_mA(&mx64, goalCurrent_mA);
        }
        presentTimeUs = get_cpu_time_in_microsec();
        t_s = presentTimeUs / 1.0e6;
#ifdef SHOW_LATENCY 
        if (nb_sample > 0) {
            latencyUS = presentTimeUs - oldTimeUs;
            oldTimeUs = presentTimeUs;
            if (nb_sample == 1) {
                maxLatencyUS = latencyUS;
                minLatencyUS = latencyUS;
                meanLatencyUS = 0;
            }
            if (latencyUS > maxLatencyUS) {
                maxLatencyUS = latencyUS;
            } else if (latencyUS < minLatencyUS) {
                minLatencyUS = latencyUS;
            }
            meanLatencyUS += latencyUS;
            k_latency++;

        }
#endif
        mx64_read_data(&mx64, &(mx64.data[col_debut]), col_debut, 1 + col_fin - col_debut);
        current_inc = mx64.data[P_CURRENT_L] + (((int) mx64.data[P_CURRENT_H]) << 8);
        meanCurrent_inc += current_inc;
        powCurrent_inc += current_inc*current_inc;
        k_mes++;
        memcpy(&(sd.data[nb_sample][col_debut]), &(mx64.data[col_debut]), 1 + col_fin - col_debut);
        sd.t_us[nb_sample] = presentTimeUs;
        // Print result
        nb_sample++;
    } while ((t_s < total_time_s)&&(nb_sample < NB_ECH_MAX));
    //----------------------------
    // Couple =0
    //----------------------------
    mx64_set_goal_torque_mA(&mx64, 0);
    presentTimeUs = get_cpu_time_in_microsec();


    //----------------------------
    // attend 1 seconde et arrete le mode couple
    //----------------------------
    while (get_cpu_time_in_microsec() < presentTimeUs + 1000000);
    mx64_turn_off_torque_mode(&mx64);
    //----------------------------
    // Ecriture données
    //----------------------------    //----------------------------
    // Ecriture données
    //----------------------------

    sd.nb_col = MX64_DATA_SIZE;
    sd.nb_sample = nb_sample;
    get_string_date(date, 1000);
    if (maxCurrent_mA < 0) {
        snprintf(s_maxSpeed, 100, "m%drpmX100", (int) (-maxCurrent_mA * 100));
    } else {
        snprintf(s_maxSpeed, 100, "%drpmX100", (int) (maxCurrent_mA * 100));
    }
    if (minCurrent_mA < 0) {
        snprintf(s_minSpeed, 100, "m%drpmX100", (int) (-minCurrent_mA * 100));
    } else {
        snprintf(s_minSpeed, 100, "%drpmX100", (int) (minCurrent_mA * 100));
    }

    if (maxCurrent_mA != minCurrent_mA) {
        snprintf(file_name, 1000, "test_%s_VitesseSinus%dmHz_%s_%s.m", date, (int) (f_hz * 1000), s_minSpeed, s_maxSpeed);
    } else {
        snprintf(file_name, 1000, "test_%s_VitesseCte_%s.m", date, s_minSpeed);
    }
    file_print_data_testCoupleConstant(&sd, file_name, col_debut, col_fin);
#ifdef SHOW_LATENCY
    meanLatencyUS /= k_latency;
    printf("%% min Latency= %f ms, max Latency =%f ms, mean Latency = %f ms\n",
            (float) (minLatencyUS * 0.001), (float) (maxLatencyUS * 0.001), (float) (meanLatencyUS * 0.001)


            );
#endif
    //----------------------------
    // Arret communication
    //----------------------------

    dxl_terminate();
    meanCurrent_inc /= k_mes;
    powCurrent_inc /= k_mes;
    varCurrent_inc = powCurrent_inc - meanCurrent_inc*meanCurrent_inc;
    if (varCurrent_inc < 0) {
        varCurrent_inc = 0;
    }
    sdCurrent_inc = sqrt(varCurrent_inc);
    meanCurrent_mA = scale(meanCurrent_inc, 0, 4095, -9211.5, 9211.5, mytrue);
    sdCurrent_mA = scale(sdCurrent_inc, 0, 2047.5, 0, 9211.5, mytrue);
    printf(" ref Current  min = %f mA , max = %f mA \n", minCurrent_mA, maxCurrent_mA);
    printf("//---------------------------------------------\n");
    printf("  estimation on %d samples \n", k_mes);
    printf("  mean Current meas = %f mA, sd_current = %f mA \n", meanCurrent_mA, sdCurrent_mA);
    printf("//---------------------------------------------\n");

    return 0;
}
