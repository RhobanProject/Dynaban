//##########################################################
//##                      R O B O T I S                   ##
//##          ReadWrite Example code for Dynamixel.       ##
//##                                           2009.11.10 ##
//##########################################################
#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include <math.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"
#include "util.h"


void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);

int main_TestVitesseEnRampe() {
    char ok;
    int baudnum = DEFAULT_BAUDNUM;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceID = DEFAULT_ID;

    int GoalPos = 359;
    float PresentLoadNcm;
    float PresentPosDegree, PresentSpeedRpm, PresentLoadNm, PresentPosRad, PresentSpeedRadps, PresentCurrentA;
    long int PresentTimeUs;
    mx64_struct mx64;
    ok = init_mx64(&mx64, deviceID, deviceIndex, baudnum);

    printf("data=struct();\n");
    printf("%% Reglage:\n");
    // On fixe la vitesse max, accélération max
    float max_speed_rpm = 100.0;
    float max_acceleration_dps2 = 1000.0;
    ok = mx64_set_speed_limit_rpm(&mx64, max_speed_rpm);
    ok = mx64_set_goal_acceleration_dps2(&mx64, max_acceleration_dps2);
    float max_speed_radps = max_speed_rpm * 2 * PI / 60;
    float max_acceleration_radps2 = max_acceleration_dps2 * PI / 180;
    printf("data.vit_max_rad_s=%f;\n", max_speed_radps);
    printf("data.acc_max_rad_s2=%f;\n", max_acceleration_radps2);
    printf("data.description_experience=\"rampe de vitesse, avec asservissement\";\n");
    printf("data.values=zeros(10000,5);");
    printf("%% Indices des colonnes de données\n");
    printf("data.col_time=1;\n");
    printf("data.col_position=2;\n");
    printf("data.col_vitesse=3;\n");
    printf("data.col_current=4;\n");
    printf("data.col_load=5;\n");
    printf("i=0;\n");

    // On se place a la position 0°
    mx64_set_goal_position_degree(&mx64, 0);
    sleep(5); // On attend d'arriver à la position    

    int i = 0;
    while (1) {
        printf("%%Press Enter key to continue!(press ESC and Enter to quit)\n");
        if (getchar() == 0x1b)
            break;

        mx64_set_goal_position_degree(&mx64, GoalPos);
        do {
            // Read PresentPos, PresentSpeed, PresentLoad, PresentCurrent
            mx64_read_position_degree(&mx64, &PresentPosDegree);
            mx64_read_speed_rpm(&mx64, &PresentSpeedRpm);
            mx64_read_load_Ncm(&mx64, &PresentLoadNcm);
            mx64_read_current_A(&mx64, &PresentCurrentA);
            PresentTimeUs = get_cpu_time_in_microsec();
            // Convert to USI
            PresentPosRad = PresentPosDegree * PI / 180;
            PresentSpeedRadps = PresentSpeedRpm * 2 * PI / 60;
            PresentLoadNm = (float) PresentLoadNcm / 100;

            // Print result
            printf("i=i+1;data.values(i,:)=[%ld,%f,%f,%f,%f];\n", PresentTimeUs, PresentPosRad, PresentSpeedRadps, PresentCurrentA, PresentLoadNm);
            i++;
        } while (PresentPosDegree < (GoalPos - 5) && i < 500);
    }
    printf("%%data.values=data.values(i,:);\n");

    // Close device
    dxl_terminate();
    printf("%%Press Enter key to terminate...\n");
    getchar();
    return 0;
}
