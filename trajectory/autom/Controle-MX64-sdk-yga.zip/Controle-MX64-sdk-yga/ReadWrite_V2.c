//##########################################################
//##                      R O B O T I S                   ##
//##          ReadWrite Example code for Dynamixel.       ##
//##                                           2009.11.10 ##
//##########################################################
#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include "dynamixel.h"
#include "Common.h"


void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);

int main_ReadWrite_V2() {
    int baudnum = DEFAULT_BAUDNUM;
    int GoalPos[2] = {0, 1023};
    //int GoalPos[2] = {0, 4095}; // for Ex series
    int index = 0;
    int deviceIndex = 0;
    int Moving, PresentPos, PresentSpeed;
    int CommStatus;

    printf("\n\nRead/Write example for Linux\n\n");
    ///////// Open USB2Dynamixel ////////////
    if (dxl_initialize(deviceIndex, baudnum) == 0) {
        printf("Failed to open USB2Dynamixel!\n");
        printf("Press Enter key to terminate...\n");
        getchar();
        return 0;
    } else
        printf("%%Succeed to open USB2Dynamixel!\n");
    // LED ON /OFF : 25 (0X19)

    // Read model_number
    int model_number = dxl_read_word(DEFAULT_ID, P_MODEL_NUMBER_L);
    CommStatus = dxl_get_result();

    if (CommStatus == COMM_RXSUCCESS) {
        printf("Succed to read model_number : %d\n", model_number);
        PrintErrorCode();
    } else {
        printf("failed to read model_number, CommStatus is %d", CommStatus);
        PrintCommStatus(CommStatus);
    }

    // Read baud_rate
    int baud_rate = dxl_read_byte(DEFAULT_ID, P_BAUD_RATE);
    CommStatus = dxl_get_result();

    if (CommStatus == COMM_RXSUCCESS) {
        printf("Succed to read baud_rate : %d\n", baud_rate);
        PrintErrorCode();
    } else {
        printf("failed to read baud_rate, CommStatus is %d", CommStatus);
        PrintCommStatus(CommStatus);
    }
    // Write baud_rate
    baud_rate = V_BAUD_RATE_1MHZ;
    dxl_write_byte(DEFAULT_ID, P_BAUD_RATE, baud_rate);
    CommStatus = dxl_get_result();

    if (CommStatus == COMM_RXSUCCESS) {
        printf("Succed to read baud_rate : %d\n", baud_rate);
        PrintErrorCode();
    } else {
        printf("failed to read baud_rate, CommStatus is %d", CommStatus);
        PrintCommStatus(CommStatus);
    }

    // Write  P_LED
    dxl_write_byte(DEFAULT_ID, P_LED, 2);


    printf("Press Enter key to continue!(press ESC and Enter to quit)\n");
    if (getchar() == 0x1b) {
        dxl_terminate();
        return 0;
    }

    while (1) {
        printf("Press Enter key to continue!(press ESC and Enter to quit)\n");
        if (getchar() == 0x1b)
            break;

        // Write goal position
        dxl_write_word(DEFAULT_ID, P_GOAL_POSITION_L, GoalPos[index]);
        do {
            // Read present position
            PresentPos = dxl_read_word(DEFAULT_ID, P_PRESENT_POSITION_L);
            CommStatus = dxl_get_result();

            if (CommStatus == COMM_RXSUCCESS) {
                printf("GoalPos[%d] = %d   Pos = %d ", index, GoalPos[index], PresentPos);
                PrintErrorCode();
            } else {
                PrintCommStatus(CommStatus);
                break;
            }

            PresentSpeed = dxl_read_word(DEFAULT_ID, P_PRESENT_SPEED_L);
            CommStatus = dxl_get_result();

            if (CommStatus == COMM_RXSUCCESS) {
                printf("Speed = %d\n", PresentSpeed);
                PrintErrorCode();
            } else {
                PrintCommStatus(CommStatus);
                break;
            }

            // Check moving done
            Moving = dxl_read_byte(DEFAULT_ID, P_MOVING);
            CommStatus = dxl_get_result();
            if (CommStatus == COMM_RXSUCCESS) {
                if (Moving == 0) {
                    // Change goal position
                    if (index == 0)
                        index = 1;
                    else
                        index = 0;
                }

                PrintErrorCode();
            } else {
                PrintCommStatus(CommStatus);
                break;
            }
        } while (Moving == 1);
    }

    // Close device
    dxl_terminate();
    printf("Press Enter key to terminate...\n");
    getchar();
    return 0;
}
