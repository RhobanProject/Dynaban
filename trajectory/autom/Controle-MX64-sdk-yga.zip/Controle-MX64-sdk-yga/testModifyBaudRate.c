#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include <math.h>
#include <bits/stdio2.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"
#include "dynamixel.h"
#include "util.h"
#include <math.h>
void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);

int main_ModifyBaudRate() {
    int initial_baud_num;
    char ok;
    char file_name[1000], date[1000];
    int baudnum = DEFAULT_BAUDNUM;
    int new_baudnum=V_BAUD_RATE_3MHZ;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceIDAllMotors = ID_ALL_MOTORS;
    int deviceIDThisMotor = DEFAULT_ID;
    if (dxl_initialize(deviceIndex, baudnum) == 0) {
        printf("%%Failed to open USB2Dynamixel!\n");
        printf("%%Press Enter key to terminate...\n");
        getchar();
        return 0;
    }
    printf("%%Succeed to open USB2Dynamixel!\n");
    initial_baud_num=dxl_read_byte(deviceIDThisMotor, P_BAUD_RATE);
    printf(" initial bau num = %d\n", initial_baud_num);
    printf(" set baud num to all motors = %d\n", new_baudnum);
    dxl_write_byte(deviceIDAllMotors, P_BAUD_RATE,new_baudnum);
    dxl_terminate();

    return 0;
}

