/* 
 * File:   newmain.c
 * Author: ygorra
 *
 * Created on 6 novembre 2014, 12:47
 */

#include <stdio.h>
#include <stdlib.h>
#include "dynamixel.h"

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

