//##########################################################
//##                      R O B O T I S                   ##
//##          ReadWrite Example code for Dynamixel.       ##
//##                                           2009.11.10 ##
//##########################################################
#include <stdio.h>
#include <termio.h>
#include <unistd.h>
#include "dynamixel.h"
#include "Common.h"
#include "MX-64.h"
#include "util.h"


void PrintCommStatus(int CommStatus);
void PrintErrorCode(void);

int main_TestVitesseLente() {
    int CommStatus;
    int baudnum = DEFAULT_BAUDNUM;
    int deviceIndex = DEFAULT_DEVICE_INDEX;
    int deviceID = DEFAULT_ID;

    int GoalPos[2] = {0, 1023};
    //int GoalPos[2] = {0, 4095}; // for Ex series
    int index = 0;
    int Moving;
    float PresentLoadNcm, PresentPosDegree, PresentSpeedRpm;

    printf("\n\n%%Test on MX-64-AT \n\n");
    char ok;
    mx64_struct mx64;
    ok = init_mx64(&mx64, deviceID, deviceIndex, baudnum);

    // Read baud_rate
    int baud_rate;
    ok = mx64_read_baudrate(&mx64, &baud_rate);

    int max_speed_rpm = 1;
    ok = mx64_set_speed_limit_rpm(&mx64, max_speed_rpm);



    int i = 1;
    printf("position_degree = zeros ( 2,1 ); speed_rpm = zeros ( 2, 1 ); load_Ncm = zeros ( 2, 1 ); timeUs = zeros ( 2, 1 );\n");
    long int PresentTimeUs;
    while (1) {
        printf("%%Press Enter key to continue!(press ESC and Enter to quit)\n");
        if (getchar() == 0x1b)
            break;

        mx64_set_goal_position_degree(&mx64, GoalPos[index]);
        do {
            // Read PresentPos, PresentSpeed, PresentLoad
            mx64_read_position_degree(&mx64, &PresentPosDegree);
            mx64_read_speed_rpm(&mx64, &PresentSpeedRpm);
            mx64_read_load_Ncm(&mx64, &PresentLoadNcm);

            // Print result
            printf("position_degree ( %d ) = %f; speed_rpm ( %d ) = %f; load_Ncm ( %d ) = %f;", i, PresentPosDegree, i, PresentSpeedRpm, i, PresentLoadNcm);
            PresentTimeUs = get_cpu_time_in_microsec();
            printf("timeUs ( %d ) = %ld;\n", i, PresentTimeUs);
            // Check Moving
            ok = mx64_read_moving(&mx64, &Moving);
            if (ok) {
                if (Moving == 0) {
                    // Change goal position
                    if (index == 0)
                        index = 1;
                    else
                        index = 0;
                }
            } else {
                PrintCommStatus(CommStatus);
                break;
            }
            i++;
        } while (Moving == 1);
    }
    printf("figure(1); clf (); ");
    // Close device
    dxl_terminate();
    printf("%%Press Enter key to terminate...\n");
    getchar();
    return 0;
}
